package com.nttdata.ct.web.runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = "com.nttdata.ct.web.glue",
        plugin = {"pretty", "json:target/cucumber-report.json"},
        monochrome = true
)
public class RunnerTest {
    // Runner vacío
}
