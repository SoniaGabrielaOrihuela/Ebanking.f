package com.nttdata.ct.web.page;

public class StepPages {
    public LoginPage loginPage() { return new LoginPage(); }
    public TransferPage transferPage() { return new TransferPage(); }
    public SummaryPage summaryPage() { return new SummaryPage(); }
}
