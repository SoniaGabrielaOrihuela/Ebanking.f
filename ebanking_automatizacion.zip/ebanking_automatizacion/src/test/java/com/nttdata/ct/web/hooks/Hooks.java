package com.nttdata.ct.web.hooks;

import com.nttdata.ct.web.lib.WebDriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {

    private final WebDriverManager manager = WebDriverManager.getInstance();

    @Before
    public void beforeScenario() {
        // si quieres navegar aquí, hazlo; en el glue navegamos en @Before de TransferStepDefinition
    }

    @After
    public void afterScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            String name = scenario.getName().replaceAll("[^a-zA-Z0-9\\-]", "_") + ".png";
            manager.takeScreenshot(name);
        }
        manager.quit();
    }
}
