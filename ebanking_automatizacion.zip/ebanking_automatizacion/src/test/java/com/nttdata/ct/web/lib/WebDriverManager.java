package com.nttdata.ct.web.lib;

import com.nttdata.ct.web.base.WebBase;
import org.openqa.selenium.WebDriver;

public class WebDriverManager extends WebBase {

    private static final WebDriverManager INSTANCE = new WebDriverManager();

    private WebDriverManager() { }

    public static WebDriverManager getInstance() {
        return INSTANCE;
    }

    public void navigateTo(String url) {
        getDriver().navigate().to(url);
    }

    public WebDriver getWebDriver() {
        return getDriver();
    }

    // alias para Hooks que desea usar takeScreenshot/quitDriver
    public void takeScreenshot(String name) {
        super.takeScreenshot(name);
    }

    public void quit() {
        super.quitDriver();
    }
}
