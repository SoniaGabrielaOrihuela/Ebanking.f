package com.nttdata.ct.web.page;

import com.nttdata.ct.web.base.WebBase;
import java.time.Duration;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends WebBase {

    @FindBy(xpath = "//input[@id=\"signInName\"]")
    protected WebElement inputUsuario;

    @FindBy(xpath = "//input[@id=\"password\"]")
    protected WebElement inputContrasena;

    @FindBy(xpath = "//button[@id=\"next\"]")
    protected WebElement btnNext;

    public LoginPage() { }

    public void verificarEnLogin() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputUsuario));
    }

    public void ingresarUsuario(String usuario) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputUsuario));
        inputUsuario.clear();
        inputUsuario.sendKeys(usuario);
    }

    public void ingresarContrasena(String clave) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputContrasena));
        inputContrasena.clear();
        inputContrasena.sendKeys(clave);
    }

    public void clickNext() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(btnNext));
        btnNext.click();
    }
}
