package com.nttdata.ct.web.glue;

import com.nttdata.ct.web.lib.WebDriverManager;
import com.nttdata.ct.web.step.TransferSteps;
import io.cucumber.java.en.*;
import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;

public class TransferStepDefinition {

    private final TransferSteps steps = new TransferSteps();
    private final WebDriverManager manager = WebDriverManager.getInstance();
    private final String BASE_URL = "https://newobw-dev.sanper.com.pe";

    @Before
    public void setUp() {
        manager.navigateTo(BASE_URL);
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            String name = scenario.getName().replaceAll("[^a-zA-Z0-9\\-]", "_") + ".png";
            manager.takeScreenshot(name);
        }
        manager.quit();
    }

    @Given("que estoy en el login de E-banking")
    public void estoy_en_login() {
        steps.verificarEnLogin();
    }

    @And("ingreso en el campo Usuario {string}")
    public void ingreso_usuario(String usuario) {
        steps.ingresarUsuario(usuario);
    }

    @And("ingreso en el campo Contraseña {string}")
    public void ingreso_contrasena(String clave) {
        steps.ingresarContrasena(clave);
        steps.clickNext();
    }

    @When("doy click en el menú {string}")
    public void click_menu(String menu) {
        if ("Transferencias".equalsIgnoreCase(menu)) {
            steps.clickMenuTransferencias();
        } else {
            throw new UnsupportedOperationException("Menu no soportado: " + menu);
        }
    }

    @And("doy click en la opción {string}")
    public void click_opcion(String opcion) {
        if ("A terceros".equalsIgnoreCase(opcion)) {
            steps.clickOpcionATerceros();
        } else if ("Santander".equalsIgnoreCase(opcion)) {
            steps.clickBancoSantander();
        } else {
            throw new UnsupportedOperationException("Opción no soportada: " + opcion);
        }
    }

    @And("selecciono la Moneda {string}")
    public void selecciono_moneda(String moneda) {
        steps.seleccionarMoneda(moneda);
    }

    @And("ingreso el Importe {string}")
    public void ingreso_importe(String importe) {
        steps.ingresarImporte(importe);
    }

    @And("selecciono la Cuenta de cargo {string}")
    public void selecciono_cuenta_cargo(String cuenta) {
        steps.seleccionarCuentaCargo(cuenta);
    }

    @And("ingreso la Cuenta de destino {string}")
    public void ingreso_cuenta_destino(String cuenta) {
        steps.ingresarCuentaDestino(cuenta);
    }

    @And("ingreso el Concepto {string}")
    public void ingreso_concepto(String concepto) {
        steps.ingresarConcepto(concepto);
    }

    @And("ingreso los Correos electrónicos {string}")
    public void ingreso_correos(String correos) {
        steps.ingresarCorreos(correos);
    }

    @And("ingreso el Mensaje {string}")
    public void ingreso_mensaje(String mensaje) {
        steps.ingresarMensaje(mensaje);
    }

    @And("doy click al botón {string}")
    public void doy_click_al_boton(String boton) {
        if ("Continuar".equalsIgnoreCase(boton)) {
            steps.clickContinuar();
        } else if ("Enviar a pendiente de firma".equalsIgnoreCase(boton)) {
            steps.enviarAPendienteYValidar();
        } else {
            throw new UnsupportedOperationException("Botón no soportado: " + boton);
        }
    }

    @Then("se muestra el resumen con todos los datos ingresados, incluida la cuenta de cargo, cuenta destinataria, titular, documento, referencia, moneda e importe")
    public void valida_resumen() {
        steps.validarResumenConDatos();
    }

    @Then("se valida que la transferencia fue creada correctamente y queda en estado {string} con un identificador de operación visible")
    public void valida_pendiente_con_id(String estado) {
        steps.enviarAPendienteYValidar();
    }
}
