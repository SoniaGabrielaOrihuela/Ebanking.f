package com.nttdata.ct.web.step;

import com.nttdata.ct.web.page.StepPages;
import org.junit.Assert;

public class TransferSteps {

    private final StepPages pages = new StepPages();

    public void verificarEnLogin() {
        pages.loginPage().verificarEnLogin();
    }

    public void ingresarUsuario(String usuario) {
        pages.loginPage().ingresarUsuario(usuario);
    }

    public void ingresarContrasena(String clave) {
        pages.loginPage().ingresarContrasena(clave);
    }

    public void clickNext() {
        pages.loginPage().clickNext();
    }

    public void clickMenuTransferencias() {
        pages.transferPage().clickMenuTransferencias();
    }

    public void clickOpcionATerceros() {
        pages.transferPage().clickOpcionATerceros();
    }

    public void seleccionarMoneda(String moneda) {
        pages.transferPage().seleccionarMoneda(moneda);
    }

    public void ingresarImporte(String importe) {
        pages.transferPage().ingresarImporte(importe);
    }

    public void seleccionarCuentaCargo(String cuenta) {
        pages.transferPage().seleccionarCuentaCargo(cuenta);
    }

    public void clickBancoSantander() {
        pages.transferPage().seleccionarBancoSantander();
    }

    public void ingresarCuentaDestino(String cuenta) {
        pages.transferPage().ingresarCuentaDestino(cuenta);
    }

    public void ingresarConcepto(String concepto) {
        pages.transferPage().ingresarConcepto(concepto);
    }

    public void ingresarCorreos(String correos) {
        pages.transferPage().ingresarCorreos(correos);
    }

    public void ingresarMensaje(String mensaje) {
        pages.transferPage().ingresarMensaje(mensaje);
    }

    public void clickContinuar() {
        pages.transferPage().clickContinuar();
    }

    public void validarResumenConDatos() {
        boolean ok = pages.summaryPage().validarResumenVisibleConCampos();
        Assert.assertTrue("El resumen no muestra los datos esperados.", ok);
    }

    public void enviarAPendienteYValidar() {
        pages.summaryPage().clickEnviarAPendiente();
        boolean ok = pages.summaryPage().validarEstadoPendienteYId();
        Assert.assertTrue("No se validó que la transferencia quede en Pendiente de firma con ID visible.", ok);
    }
}
