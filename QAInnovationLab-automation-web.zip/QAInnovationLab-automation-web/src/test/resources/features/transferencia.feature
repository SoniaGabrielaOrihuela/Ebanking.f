Feature: Transferencias E-banking - Crear transferencia pendiente de firma

  Scenario: Crear transferencia a terceros y dejarla en estado "Pendiente de firma"
    Given que estoy en el login de E-banking
    And ingreso en el campo Usuario "JLURAGO"
    And ingreso en el campo Contraseña "vector12"
    When doy click en el menú "Transferencias"
    And doy click en la opción "A terceros"
    And selecciono la Moneda "Dolares"
    And ingreso el Importe "75 000"
    And selecciono la Cuenta de cargo "corriente activo dólares"
    And doy click en la opción "Santander"
    And ingreso la Cuenta de destino "0008206660"
    And ingreso el Concepto "Prueba Automatizada"
    And ingreso los Correos electrónicos "sorihuela_ntt@santander.com.pe"
    And ingreso el Mensaje "Prueba Automatizada"
    And doy click al botón "Continuar"
    Then se muestra el resumen con todos los datos ingresados, incluida la cuenta de cargo, cuenta destinataria, titular, documento, referencia, moneda e importe
    And doy click al botón "Enviar a pendiente de firma"
    Then se valida que la transferencia fue creada correctamente y queda en estado "Pendiente de firma" con un identificador de operación visible