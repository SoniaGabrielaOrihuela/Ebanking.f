package com.nttdata.ct.web.base;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.IOException;


public abstract class WebBase {

    private static final ThreadLocal<WebDriver> DRIVER = new ThreadLocal<>();

    // Ruta por defecto (tu path). Fíjate en los backslashes escapados.
    private static final String DEFAULT_CHROMEDRIVER_PATH = "C:\\\\Users\\\\Sonia Gabriela\\\\Desktop\\\\prueba\\\\QAInnovationLab-automation-web\\\\drivers\\\\chromedriver.exe";

    protected WebDriver getDriver() {
        if (DRIVER.get() == null) {
            // Lee property del sistema; si no existe, usa la ruta por defecto
            String driverPath = System.getProperty("webdriver.chrome.driver");
            if (driverPath == null || driverPath.isBlank()) {
                driverPath = DEFAULT_CHROMEDRIVER_PATH;
            }
            System.setProperty("webdriver.chrome.driver", driverPath);

            // Configuro ChromeOptions (headless opcional, remote-allow-origins)
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--remote-allow-origins=*");
            // si quieres ejecución sin UI (headless), descomenta la siguiente línea:
            // options.addArguments("--headless=new");
            DRIVER.set(new ChromeDriver(options));
            DRIVER.get().manage().window().maximize();
        }
        return DRIVER.get();
    }

    protected WebDriverWait webDriverWait(Duration duration) {
        return new WebDriverWait(getDriver(), duration);
    }

    protected void quitDriver() {
        WebDriver d = DRIVER.get();
        if (d != null) {
            d.quit();
            DRIVER.remove();
        }
    }

    protected void takeScreenshot(String filename) {
        try {
            WebDriver d = getDriver();
            if (d instanceof TakesScreenshot) {
                File src = ((TakesScreenshot) d).getScreenshotAs(OutputType.FILE);
                File target = new File("target/screenshots/" + filename);
                target.getParentFile().mkdirs();
                FileHandler.copy(src, target);
            }
        } catch (IOException e) {
            System.err.println("Error guardando screenshot: " + e.getMessage());
        }
    }
}