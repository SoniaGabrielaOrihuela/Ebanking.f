package com.nttdata.ct.web.page;

import com.nttdata.ct.web.base.WebBase;
import java.time.Duration;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SummaryPage extends WebBase {

    @FindBy(xpath = "//div[@id='resumenDatos']") // placeholder
    protected WebElement contenedorResumen;

    @FindBy(xpath = "//button[normalize-space()='Enviar a pendiente de firma']") // placeholder
    protected WebElement btnEnviarPendiente;

    @FindBy(xpath = "//span[contains(text(),'Pendiente de firma')]") // placeholder
    protected WebElement estadoPendiente;

    @FindBy(xpath = "//span[@id='idOperacion']") // placeholder
    protected WebElement idOperacion;

    public SummaryPage() {}

    public boolean validarResumenVisibleConCampos() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(contenedorResumen));
        return contenedorResumen.isDisplayed();
    }

    public void clickEnviarAPendiente() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(btnEnviarPendiente));
        btnEnviarPendiente.click();
    }

    public boolean validarEstadoPendienteYId() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(estadoPendiente));
        wait.until(ExpectedConditions.visibilityOf(idOperacion));
        return estadoPendiente.isDisplayed() && idOperacion.isDisplayed();
    }
}
