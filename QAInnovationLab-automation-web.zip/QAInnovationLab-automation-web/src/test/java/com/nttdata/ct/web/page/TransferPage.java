package com.nttdata.ct.web.page;

import com.nttdata.ct.web.base.WebBase;
import java.time.Duration;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class TransferPage extends WebBase {

    // NOTE: Reemplazar los xpaths siguientes por los reales inspeccionando la UI
    @FindBy(xpath = "//a[normalize-space()='Transferencias']") // placeholder
    protected WebElement menuTransferencias;

    @FindBy(xpath = "//a[normalize-space()='A terceros']") // placeholder
    protected WebElement opcionATerceros;

    @FindBy(xpath = "//select[@id='moneda']") // placeholder
    protected WebElement selectMoneda;

    @FindBy(xpath = "//input[@id='importe']") // placeholder
    protected WebElement inputImporte;

    @FindBy(xpath = "//select[@id='cuentaCargo']") // placeholder
    protected WebElement selectCuentaCargo;

    @FindBy(xpath = "//button[normalize-space()='Santander']") // placeholder
    protected WebElement opcionSantander;

    @FindBy(xpath = "//input[@id='cuentaDestino']") // placeholder
    protected WebElement inputCuentaDestino;

    @FindBy(xpath = "//input[@id='concepto']") // placeholder
    protected WebElement inputConcepto;

    @FindBy(xpath = "//input[@id='correos']") // placeholder
    protected WebElement inputCorreos;

    @FindBy(xpath = "//textarea[@id='mensaje']") // placeholder
    protected WebElement inputMensaje;

    @FindBy(xpath = "//button[normalize-space()='Continuar']") // placeholder
    protected WebElement btnContinuar;

    public TransferPage() { }

    public void clickMenuTransferencias() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(menuTransferencias));
        menuTransferencias.click();
    }

    public void clickOpcionATerceros() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(opcionATerceros));
        opcionATerceros.click();
    }

    public void seleccionarMoneda(String monedaVisible) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(selectMoneda));
        selectMoneda.sendKeys(monedaVisible);
    }

    public void ingresarImporte(String importe) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputImporte));
        inputImporte.clear();
        inputImporte.sendKeys(importe);
    }

    public void seleccionarCuentaCargo(String cuentaVisible) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(selectCuentaCargo));
        selectCuentaCargo.sendKeys(cuentaVisible);
    }

    public void seleccionarBancoSantander() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(opcionSantander));
        opcionSantander.click();
    }

    public void ingresarCuentaDestino(String cuenta) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputCuentaDestino));
        inputCuentaDestino.clear();
        inputCuentaDestino.sendKeys(cuenta);
    }

    public void ingresarConcepto(String concepto) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputConcepto));
        inputConcepto.clear();
        inputConcepto.sendKeys(concepto);
    }

    public void ingresarCorreos(String correos) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputCorreos));
        inputCorreos.clear();
        inputCorreos.sendKeys(correos);
    }

    public void ingresarMensaje(String mensaje) {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(inputMensaje));
        inputMensaje.clear();
        inputMensaje.sendKeys(mensaje);
    }

    public void clickContinuar() {
        PageFactory.initElements(getDriver(), this);
        var wait = webDriverWait(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(btnContinuar));
        btnContinuar.click();
    }
}
